// Check current authentication state on load
document.addEventListener("DOMContentLoaded", () => {
    updateDashboardUI();
});

function loginUser() {
    const name = document.getElementById("username").value.trim();
    const email = document.getElementById("email").value.trim();

    if (!name || !email) {
        alert("Please enter both your name and email.");
        return;
    }

    const userData = {
        name: name,
        email: email,
        completedModules: JSON.parse(localStorage.getItem("completedModules")) || []
    };

    localStorage.setItem("drawingMasterUser", JSON.stringify(userData));
    updateDashboardUI();
}

function logoutUser() {
    localStorage.removeItem("drawingMasterUser");
    localStorage.removeItem("completedModules");
    updateDashboardUI();
}

function updateDashboardUI() {
    const user = JSON.parse(localStorage.getItem("drawingMasterUser"));
    const authSection = document.getElementById("auth-section");
    const dashboardSection = document.getElementById("dashboard-section");

    if (!authSection || !dashboardSection) return;

    if (user) {
        authSection.style.display = "none";
        dashboardSection.style.display = "block";

        document.getElementById("user-display-name").innerText = user.name;
        document.getElementById("user-display-email").innerText = user.email;

        const completed = JSON.parse(localStorage.getItem("completedModules")) || [];
        document.getElementById("modules-completed").innerText = `${completed.length} / 3`;

        let rank = "Beginner";
        if (completed.length === 2) rank = "Intermediate";
        if (completed.length >= 3) rank = "Advanced Master";
        document.getElementById("skill-level").innerText = rank;
    } else {
        authSection.style.display = "block";
        dashboardSection.style.display = "none";
    }
}

function completeModule(moduleNumber) {
    let user = JSON.parse(localStorage.getItem("drawingMasterUser"));
    if (!user) {
        alert("Please create an account or sign in via the Account page to track your progress!");
        window.location.href = "dashboard.html";
        return;
    }

    let completed = JSON.parse(localStorage.getItem("completedModules")) || [];
    if (!completed.includes(moduleNumber)) {
        completed.push(moduleNumber);
        localStorage.setItem("completedModules", JSON.stringify(completed));
        alert(`Module ${moduleNumber} marked as completed! Check your dashboard for updated analytics.`);
    } else {
        alert("You have already completed this module!");
    }
}